package com.example.tareas.retrofit


data class MarsProperty(
    val id: String,
    val img_src: String,
    val type: String,
    val price: Double
)
